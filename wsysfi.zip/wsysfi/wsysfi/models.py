from django.db import models

class Clientes(models.Model):
    identificacion = models.CharField(max_length=10)
    nombre = models.CharField(max_length=50)
    apellidos = models.CharField(max_length=50)
    direccion = models.CharField(max_length=150)
    celular = models.CharField(max_length=10)
    sexo = models.CharField(max_length=15)
    class Meta:
        db_table = 'clientes'

class Categorias(models.Model):
    nombre = models.CharField(max_length=50)
    descripcion = models.CharField(max_length=150)
    class Meta:
        db_table = 'categorias'

class Productos(models.Model):
    codigo=models.CharField(max_length=20)
    nombre = models.CharField(max_length=50)
    precio = models.IntegerField()
    stock  = models.IntegerField()
    foto = models.CharField(max_length=255)
    categorias=models.ForeignKey(Categorias, on_delete=models.CASCADE)
    class Meta:
        db_table = 'productos'



