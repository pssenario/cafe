from django.shortcuts import redirect, render
from django.db import connection
from wsysfi.models import *
from django.core.files.storage import FileSystemStorage
import uuid

def Inicio(request):
    return render(request,'index.html')

#region clientes

def RegistroCliente(request):
    error = None
    if request.method=='POST':
        if request.POST.get('nombre') and request.POST.get('apellido') and request.POST.get('identificacion') and request.POST.get('direccion') and request.POST.get('celular') and request.POST.get('sexo'):
            ide=request.POST.get('identificacion').strip()
            buscarIden=connection.cursor()
            buscarIden.execute("CALL buscarIde(%s)",[ide])
            existeIde=buscarIden.fetchone()
            if existeIde:
                error="El número de identificación ya exite: "+ide
            else:
                insercli = connection.cursor()
                insercli.execute("CALL insertarCliente(%s,%s,%s,%s,%s,%s)",[request.POST.get('identificacion'),request.POST.get('nombre'), request.POST.get('apellido'), request.POST.get('direccion'), request.POST.get('celular'),  request.POST.get('sexo')])
                #agregar esta linea para que redireccione a la lista de clientes
                return redirect('/clientes/lisClientes')
    return render(request, 'clientes/registroCliente.html', {'error':error})
    
    # cree este metodo
def listarClientes(request):
    listarcli = connection.cursor()
    listarcli.execute("CALL listarClientes()")
    listacli = listarcli.fetchall()
    return render(request, 'clientes/listadoClientes.html', {'listadocli': listacli})


def BorrarCliente(request):
    if request.method == 'POST':
        borrar = connection.cursor()
        borrar.execute("CALL borrarCliente(%s)",[request.POST.get('id')])
    return redirect('/clientes/lisClientes')


def ActualizarCliente(request, idcliente):
    if request.method=='POST':
        if request.POST.get('nombre') and request.POST.get('apellido') and request.POST.get('identificacion') and request.POST.get('direccion') and request.POST.get('celular') and request.POST.get('sexo'):
            insercli = connection.cursor()
            insercli.execute("CALL ActualizarCliente(%s,%s,%s,%s,%s,%s,%s)",[idcliente,request.POST.get('identificacion'),request.POST.get('nombre'), request.POST.get('apellido'), request.POST.get('direccion'), request.POST.get('celular'),  request.POST.get('sexo')])
            #agregar esta linea para que redireccione a la lista de clientes
            return redirect('/clientes/lisClientes')
    else:
        actcliente=connection.cursor()
        actcliente.execute("CALL buscarCliente(%s)",[idcliente])
        return render(request,'clientes/actualizarCliente.html',{'clienteact':actcliente})

#endregion


#region Categoria
def RegistroCategoria(request):
    if request.method=='POST':
        if request.POST.get('nombre') and request.POST.get('descripcion'):
            categoria = Categorias()
            categoria.nombre = request.POST.get('nombre')
            categoria.descripcion=request.POST.get('descripcion')
            categoria.save()
            return redirect('/categorias/lisCategorias')
    else:
        return render(request, 'categorias/registroCategoria.html')
    
def listarCategorias(request):
    lCategoria= Categorias.objects.all()
    return render(request, 'categorias/listadoCategorias.html', {'listadocat': lCategoria})

def BorrarCategoria(request):
    if request.method == 'POST':
        categoria = Categorias.objects.get(id=request.POST.get('id'))
        categoria.delete()
    return redirect('/categorias/lisCategorias')    

def ActualizarCategoria(request, idcat):
    if request.method=='POST':
        if request.POST.get('nombre') and request.POST.get('descripcion'):
            categoria = Categorias.objects.get(id=idcat)
            categoria.nombre = request.POST.get('nombre')
            categoria.descripcion=request.POST.get('descripcion')
            categoria.save()
            return redirect('/categorias/lisCategorias')
    else:
        concat=Categorias.objects.filter(id=idcat)
        return render(request, 'categorias/actualizarCategoria.html',{'categoriact':concat})
#regionend


def RegistroProducto(request):
    if request.method=='POST':
        if request.POST.get('codigo') and request.POST.get('nombre') and request.POST.get('precio') and request.POST.get('stock') and request.FILES.get('foto') and request.POST.get('categoria_id'):
            producto = Productos()
            producto.codigo=request.POST.get('codigo')
            producto.nombre=request.POST.get('nombre')
            producto.precio=request.POST.get('precio')
            producto.stock=request.POST.get('stock')
            producto.foto=request.FILES['foto']
            producto.categorias = Categorias.objects.get(id=request.POST.get('categoria_id'))
            imagen = FileSystemStorage(location='wsysfi/public/img/productos')
            nombrefoto= str(uuid.uuid4())+"-"+producto.foto.name
            imagen.save(nombrefoto,producto.foto)
            producto.foto=nombrefoto
            producto.save()
            return redirect('/productos/lisProductos')
    else:
        categorias = Categorias.objects.all().order_by('nombre')
        return render(request, 'productos/registroProducto.html',{'cate':categorias})
    
def listarProductos(request):
    lproductos= Productos.objects.all()
    return render(request, 'productos/listadoProductos.html',{'listaprod':lproductos})