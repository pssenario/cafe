from django.contrib import admin
from django.urls import path
from wsysfi.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',Inicio, name='Inicio'),

    # Rutas de Clientes
    path('clientes/regCliente',RegistroCliente, name='regCliente'),
    path('clientes/lisClientes',listarClientes, name='lisClientes'),
    path('clientes/borrarCliente', BorrarCliente, name='borrarCliente'),
    path('clientes/actualizarCliente/<str:idcliente>', ActualizarCliente, name='actualizarCliente'),

    # Rutas de Categorias
    path('categoria/regCategoria',RegistroCategoria, name='regCategoria'),
    path('categorias/lisCategorias',listarCategorias, name='lisCategorias'),
    path('categorias/borrarCategoria', BorrarCategoria, name='borrarCategoria'),
    path('categorias/actualizarCategoria/<str:idcat>', ActualizarCategoria, name='actualizarCategoria'),

        # Rutas de Categorias
    path('productos/regProducto',RegistroProducto, name='regProducto'),
    path('productos/lisProductos',listarProductos, name='lisProductos'),
]
